#!/bin/sh

bundle exec ruby app.rb
