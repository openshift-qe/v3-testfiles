package org.jboss.as.quickstarts.ear.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.as.quickstarts.ear.ejb.GreeterEJB;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/greeting")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private GreeterEJB greeter;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 * response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		response.getOutputStream().println(greeter.sayHello(name));
	}

}
