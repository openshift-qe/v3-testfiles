package org.jboss.as.quickstarts.ear.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.as.quickstarts.ear.ejb.GreeterEJB;

@WebServlet("/connectionInfo")
public class ConnectionParameterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private GreeterEJB greeter;

	public ConnectionParameterServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String paramName = request.getParameter("param");
		String returnValue = "";
		if ("secure".equals(paramName)) {
			returnValue = Boolean.toString(request.isSecure());
		}
		response.getOutputStream().println(returnValue);
	}

}
