package com.redhat.xpaas.sti;

import org.junit.Assert;
import org.junit.Test;

public class ShouldFailTest {

	@Test
	public void shouldFailTest() {
		if ("true".equals(System.getProperty("xpaas.test.fail", "false"))) {
			Assert.fail("Failed upon request");
		}
	}
}
